# Mailbit

A simple Python library to send emails using the Mailbit API.

## Installation

```sh
pip install mailbit
